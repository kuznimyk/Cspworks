﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace sort
{
    public partial class Form1 : Form
    {
        static int x;
        int g;
        DateTime tm1;
        DateTime tm2;
        TimeSpan diff1;
        TimeSpan diff2;
        TimeSpan diff3;
        public Form1()
        {
            g = 0;
            x = 0;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random r = new Random(DateTime.Now.Millisecond);
            if (textBox1.Text != "")
            {
                x = Convert.ToInt32(textBox1.Text);
            }
            for (int i =0;i < x;i++)
            {
                listBox1.Items.Add(r.Next(1,100));
            }
        }
        void sort(object h)
        {
            int a = (int)h;
            Monitor.Enter(listBox1);
            int[] arr = new int[x];
            for (int i =0;i < x;i++)
            {
                arr[i] = Convert.ToInt32(listBox1.Items[i]);
            }
            if (a == 0)
            {
                tm1 = DateTime.Now;
                for (int i =0;i < x;i++)
                {
                    for (int j =0;j < x- 1;j++)
                    {
                        if (arr[j] > arr[j+1])
                        {
                            int temp ;
                            temp = arr[j];
                            arr[j] = arr[j+1];
                            arr[j+1] = temp;
                        }
                    }
                }
                Thread.Sleep(3);
                tm2 = DateTime.Now;
                 diff1 = tm2 - tm1;
                label3.Invoke((MethodInvoker)delegate { label3.Text = "Время сортирования методом пузырька: " + diff1.ToString(); });

            }
            else if (a== 1)
            {
                tm1 = DateTime.Now;
                int max = 0;
                int temp = 0;
                for (int i =0;i < x;i++)
                {
                    max = i;
                    for (int k =1;k< x;k++)
                    {
                        if (arr[max] < arr[k])
                        {
                            max = k;
                        }
                    }
                    temp = arr[i];
                    arr[i] = arr[max];
                    arr[max] = temp;
                }
                Thread.Sleep(3);
                tm2 = DateTime.Now;
                 diff2 = tm2 - tm1;
                label2.Invoke((MethodInvoker)delegate { label2.Text = "Время сортирования методом выборки: " + diff2.ToString(); });

            }
            else
            {
                tm1 = DateTime.Now;
                int key = 0;
                int i = 0;
                for (int j = 1; j < x; j++)
                {
                    key = arr[j];
                    i = j - 1;
                    while (i >= 0 && arr[i] > key)
                    {
                        arr[i + 1] = arr[i];
                        i = i - 1;
                        arr[i + 1] = key;
                    }
                }
                Thread.Sleep(5);
                tm2 = DateTime.Now;
                 diff3 = tm2 - tm1;
                label4.Invoke((MethodInvoker)delegate { label4.Text = "Время сортирования методом вставки: " + diff3.ToString(); });

            }
            Monitor.Exit(listBox1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (g = 0; g < 3; g++)
            {
                Thread th = new Thread(sort);
                th.Start(g);
            }
            MessageBox.Show("Время сортирования методом вставки в 1.1 раз быстрее метода выборки и в 1.2 раза быстрее метода пузырьком");

        }
    }
}
