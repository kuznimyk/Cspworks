﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
namespace read
{
    class Program
    {
        static Mutex mx;

        static void Main(string[] args)
        {
            try
            {
                bool createnew;
                mx = new Mutex(false, "Mutex", out createnew);
                if (createnew == false)
                {
                    Console.WriteLine("Мютекс уже запущен");
                }
                else
                {
                    Thread th = new Thread(read);
                    th.Start();
                }
            }
            catch (Exception ex)
            {

            }
            Console.ReadKey();
        }

        static void read()
        {
            mx.WaitOne();
            using (FileStream fs = new FileStream(@"z:\\Kuznietsov\read.txt", FileMode.Open, FileAccess.Read))
            {
                StreamReader sw = new StreamReader(fs, Encoding.UTF8);
                string x = sw.ReadToEnd();
                Console.WriteLine(x);
                sw.Dispose();
            }
            mx.ReleaseMutex();
        }
    }
}
