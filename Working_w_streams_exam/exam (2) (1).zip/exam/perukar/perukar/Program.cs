﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace perukar
{
    class Program
    {
        static Semaphore sp;
        static void Main(string[] args)
        {
            sp = new Semaphore(1,2);
            for (int i = 0; i < 100000; i++)
            {
                Thread th = new Thread(dosomething);
                th.Start(i);
            }
            
        }
        static void dosomething(object obj)
        {
            Random r = new Random(DateTime.Now.Millisecond);
            sp.WaitOne();
            if (1 == r.Next(1,3))
            {
                Console.WriteLine("Клієнт номер {0} будить перукаря",(int)obj);
                Thread.Sleep(10000);
                Console.WriteLine("Клієнт номер {0} засинає,а перукар робить йому стрижку", (int)obj);
                Thread.Sleep(5000);
                if (r.Next(1, 2) == 1)
                {
                    Console.WriteLine("До перукаря прихоидть новий клієнт, який засинає");
                    Thread.Sleep(10000);
                    Console.WriteLine("Перукар будить старого клієнта та проводить його не вихід");
                    Console.WriteLine("Новий клієнт просинається та сідає на стрижку");
                    Thread.Sleep(10000);
                }
                else
                {
                    Console.WriteLine("Перукар проводжає клієнта та засинає");
                }
                sp.Release();
            }
            else if (2 == r.Next(1,3))
            {
                for (int i = 0; i < 3; i++)
                {
                    Console.WriteLine("Zzzzz....");
                    Thread.Sleep(3000);
                }
                sp.Release();
            }
            else 
            {
                Console.WriteLine("Перукар засинає");
                Thread.Sleep(7000);
                sp.Release();
            }
        }
    }
}
