﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
namespace write
{
    class Program
    {
        static Mutex mx;
        string x;
        static void Main(string[] args)
        {
            mx = new Mutex(false, "Mutex");
            Thread th = new Thread(write);
            th.Start();
            Console.ReadKey();
        }
        static void write()
        {
            mx.WaitOne();
            string x;
            mx.WaitOne();
            using (FileStream fs = new FileStream(@"z:\\Kuznietsov\read.txt", FileMode.Open, FileAccess.Read))
            {
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                x = sr.ReadToEnd();
                sr.Dispose();
            }
            using (FileStream fs = new FileStream(@"z:\\Kuznietsov\write.txt", FileMode.Open, FileAccess.Write))
            {
                StreamWriter sr = new StreamWriter(fs, Encoding.UTF8);
                sr.WriteLine(x);
                sr.Dispose();
            }
            mx.ReleaseMutex();
        }
    }
}
