﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ComboBox cmb;
        string locfio = "";
        string locdate = "";
        string locpath = "";
        string locphone = "";
        string locemail = "";
        string locexp = "";
        string add1 = "";
        string add2 = "";
        string add3 = "";
        int slide;
        public MainWindow()
        {
            InitializeComponent();
            slide = 1;
            //buutons
            next.Visibility = Visibility.Hidden;
            prev.Visibility = Visibility.Hidden;
            //buuton save into file
            intofile.Visibility = Visibility.Hidden;
            sohr.Visibility = Visibility.Hidden;
            sohrlabel.Visibility = Visibility.Hidden;
            //input textboxex 
            fio.Visibility = Visibility.Hidden;
            birth.Visibility = Visibility.Hidden;
            path.Visibility = Visibility.Hidden;
            phone.Visibility = Visibility.Hidden;
            email.Visibility = Visibility.Hidden;
            exp.Visibility = Visibility.Hidden;

            //input labels
            fiolabel.Visibility = Visibility.Hidden;
            birthlabel.Visibility = Visibility.Hidden;
            pathlabel.Visibility = Visibility.Hidden;
            phonelabel.Visibility = Visibility.Hidden;
            emaillabel.Visibility = Visibility.Hidden;
            explabel.Visibility = Visibility.Hidden;

            //additional textboxex
            additional1.Visibility = Visibility.Hidden;
            additional2.Visibility = Visibility.Hidden;
            additional3.Visibility = Visibility.Hidden;

            //additional labels
            additional1.Visibility = Visibility.Hidden;
            additional2label.Visibility = Visibility.Hidden;
            additional3label.Visibility = Visibility.Hidden;
        }

        private void chose_Click(object sender, RoutedEventArgs e)
        {
            if (shabl.SelectedItem != null)
            {
                slide++;
                chose.Visibility = Visibility.Hidden;
                shabl.Visibility = Visibility.Hidden;
                label1.Visibility = Visibility.Hidden;

                next.Visibility = Visibility.Visible;
                prev.Visibility = Visibility.Visible;


                fio.Visibility = Visibility.Visible;
                birth.Visibility = Visibility.Visible;
                path.Visibility = Visibility.Visible;
                phone.Visibility = Visibility.Visible;
                email.Visibility = Visibility.Visible;
                exp.Visibility = Visibility.Visible;

                //input labels
                fiolabel.Visibility = Visibility.Visible;
                birthlabel.Visibility = Visibility.Visible;
                pathlabel.Visibility = Visibility.Visible;
                phonelabel.Visibility = Visibility.Visible;
                emaillabel.Visibility = Visibility.Visible;
                explabel.Visibility = Visibility.Visible;
            }
            
        }

        private void next_Click(object sender, RoutedEventArgs e)
        {
            if (slide == 2 )
            {
                slide++;
                
                additional1.Visibility = Visibility.Visible;
                additional2.Visibility = Visibility.Visible;
                additional3.Visibility = Visibility.Visible;
                sohr.Visibility = Visibility.Visible;
                sohrlabel.Visibility = Visibility.Visible;
                //additional labels
                additional1.Visibility = Visibility.Visible;
                additional2label.Visibility = Visibility.Visible;
                additional3label.Visibility = Visibility.Visible;
                StackPanel sp = shabl.SelectedItem as StackPanel;
                Label l = (Label)sp.Children[1] ;
                string[] cont = ((string)l.Content).Split(',');
                try
                { 
                    additional1label.Content = cont[0];
                    additional2label.Content = cont[1];
                    additional3label.Content = cont[2];
                }
                catch(IndexOutOfRangeException ex)
                {
                    additional1label.Content = cont[0];
                    additional2label.Content = cont[1];
                    additional3.Visibility = Visibility.Hidden;
                }
                //input textboxex 
                fio.Visibility = Visibility.Hidden;
                birth.Visibility = Visibility.Hidden;
                path.Visibility = Visibility.Hidden;
                phone.Visibility = Visibility.Hidden;
                email.Visibility = Visibility.Hidden;
                exp.Visibility = Visibility.Hidden;

                //input labels
                fiolabel.Visibility = Visibility.Hidden;
                birthlabel.Visibility = Visibility.Hidden;
                pathlabel.Visibility = Visibility.Hidden;
                phonelabel.Visibility = Visibility.Hidden;
                emaillabel.Visibility = Visibility.Hidden;
                explabel.Visibility = Visibility.Hidden;
                intofile.Visibility = Visibility.Visible;

            }
        }

        private void prev_Click(object sender, RoutedEventArgs e)
        {
            if (slide == 3)
            {
                slide--;
                fio.Visibility = Visibility.Visible;
                birth.Visibility = Visibility.Visible;
                path.Visibility = Visibility.Visible;
                phone.Visibility = Visibility.Visible;
                email.Visibility = Visibility.Visible;
                exp.Visibility = Visibility.Visible;
                sohr.Visibility = Visibility.Hidden;
                sohrlabel.Visibility = Visibility.Hidden;
                //input labels
                fiolabel.Visibility = Visibility.Visible;
                birthlabel.Visibility = Visibility.Visible;
                pathlabel.Visibility = Visibility.Visible;
                phonelabel.Visibility = Visibility.Visible;
                emaillabel.Visibility = Visibility.Visible;
                explabel.Visibility = Visibility.Visible;

                //additional textboxex
                additional1.Visibility = Visibility.Hidden;
                additional2.Visibility = Visibility.Hidden;
                additional3.Visibility = Visibility.Hidden;

                //additional labels
                additional1.Visibility = Visibility.Hidden;
                additional2label.Visibility = Visibility.Hidden;
                additional3label.Visibility = Visibility.Hidden;
                intofile.Visibility = Visibility.Hidden;

            }
            else if (slide== 2)
            {
                slide--;
                chose.Visibility = Visibility.Visible;
                shabl.Visibility = Visibility.Visible;
                label1.Visibility = Visibility.Visible;

                next.Visibility = Visibility.Hidden;
                prev.Visibility = Visibility.Hidden;


                fio.Visibility = Visibility.Hidden;
                birth.Visibility = Visibility.Hidden;
                path.Visibility = Visibility.Hidden;
                phone.Visibility = Visibility.Hidden;
                email.Visibility = Visibility.Hidden;
                exp.Visibility = Visibility.Hidden;

                fio.Text = "";
                birth.Text = "";
                path.Text = "";
                phone.Text = "";
                email.Text = "";
                exp.Text = "";
                additional1.Text = "";
                additional2.Text = "";
                additional3.Text = "";
                sohr.Text = "";
                //input labels
                fiolabel.Visibility = Visibility.Hidden;
                birthlabel.Visibility = Visibility.Hidden;
                pathlabel.Visibility = Visibility.Hidden;
                phonelabel.Visibility = Visibility.Hidden;
                emaillabel.Visibility = Visibility.Hidden;
                explabel.Visibility = Visibility.Hidden;


            }
        }

        private void intofile_Click(object sender, RoutedEventArgs e)
        {
            add1 = (string)additional1.Text;
            add2 = (string)additional2.Text;
            add3 = (string)additional3.Text;
            locfio = (string)fio.Text;
            locdate = (string)birth.Text;
            locpath = (string)path.Text;
            locphone = (string)phone.Text;
            locemail = (string)email.Text;
            locexp = (string)exp.Text;
            string x = (string)sohr.Text;
            try
            {
                FileStream fs = new FileStream(x, FileMode.CreateNew, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs, Encoding.UTF8);
                sw.WriteLine(locfio + " ");
                sw.WriteLine(locdate + " " );
                sw.WriteLine(locpath + " ");
                sw.WriteLine(locphone + " ");
                sw.WriteLine(locemail + " ");
                sw.WriteLine(locexp + " ");
                sw.WriteLine(add1 + " ");
                sw.WriteLine(add2 + " ");
                sw.WriteLine(add3 + " ");
                sw.Dispose();
                fs.Dispose();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Такого файла не существует");
            }
        }
    }
}
